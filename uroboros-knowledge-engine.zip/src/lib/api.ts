import { FileNode, GraphLink, GraphNode, SearchResult } from '../types';

const BASE_URL = '/api';

async function fetchAPI<T>(endpoint: string, options?: RequestInit): Promise<T> {
  try {
    const res = await fetch(`${BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers || {}),
      },
    });
    if (!res.ok) {
      throw new Error(`API Error: ${res.status}`);
    }
    const contentType = res.headers.get('content-type');
    if (contentType && contentType.includes('text/html')) {
       throw new Error('Expected JSON, got HTML');
    }
    return await res.json();
  } catch (err) {
    console.warn(`Fallback triggered for ${endpoint}`);
    throw err;
  }
}

// Stubs for graceful degradation when API is not available (like in preview)
export const api = {
  health: () => fetchAPI<any>('/health').catch(() => ({ status: 'Mock OK', uptime: '1h', version: '1.0' })),
  stats: () => fetchAPI<any>('/stats').catch(() => ({ cpu: '12%', ram: '2.4GB' })),
  
  // Dashboard
  storage: () => fetchAPI<any>('/analytics/storage').catch(() => ({
    distribution: [
      { mime: 'application/pdf', bytes: 1024 * 1024 * 500 },
      { mime: 'image/png', bytes: 1024 * 1024 * 120 },
      { mime: 'text/markdown', bytes: 1024 * 1024 * 10 },
      { mime: 'audio/mpeg', bytes: 1024 * 1024 * 800 },
    ],
    totalBytes: 1024 * 1024 * 1430
  })),
  tags: () => fetchAPI<any>('/analytics/tags').catch(() => ({ matrix: [] })),
  searchActivity: () => fetchAPI<any>('/analytics/search-activity').catch(() => ({ 
    timeline: [
      { date: 'Mon', searches: 140, indexed: 20 },
      { date: 'Tue', searches: 210, indexed: 45 },
      { date: 'Wed', searches: 180, indexed: 10 },
      { date: 'Thu', searches: 290, indexed: 110 },
      { date: 'Fri', searches: 240, indexed: 35 },
      { date: 'Sat', searches: 110, indexed: 5 },
      { date: 'Sun', searches: 90, indexed: 2 },
    ] 
  })),
  recentSearches: () => fetchAPI<any>('/search/history').catch(() => ([
    { id: 1, query: 'quantum field theory', time: '10m ago', mode: 'Semantic', status: 'success' },
    { id: 2, query: 'tax documents 2024', time: '1h ago', mode: 'Keyword', status: 'success' },
    { id: 3, query: 'project q4 roadmaps', time: '3h ago', mode: 'Semantic', status: 'success' },
    { id: 4, query: 'error logs api gateway', time: '5h ago', mode: 'Semantic', status: 'failed' },
  ])),
  fileTree: () => fetchAPI<FileNode[]>('/file/tree').catch(() => ([
    { id: '1', name: 'documents', path: '/documents', type: 'directory', children: [
      { id: '2', name: 'research.pdf', path: '/documents/research.pdf', type: 'file', mime: 'application/pdf' },
      { id: '3', name: 'notes.md', path: '/documents/notes.md', type: 'file', mime: 'text/markdown' },
    ]}
  ])),
  
  // Search
  search: (query: string, mode: string, threshold: number) => fetchAPI<SearchResult[]>(`/search?q=${encodeURIComponent(query)}&mode=${mode}&threshold=${threshold}`).catch(() => ([
    { id: '2', filename: 'research.pdf', path: '/documents/research.pdf', mime: 'application/pdf', score: 0.95, snippet: '...quantum entanglement experiments showed significant...', tags: ['physics', 'research'], size: 2048576, date: '2025-01-15' },
    { id: '3', filename: 'notes.md', path: '/documents/notes.md', mime: 'text/markdown', score: 0.82, snippet: '...discussion on quantum computing architectures...', tags: ['notes'], size: 1024, date: '2025-01-16' }
  ])),
  
  // Graph
  graphData: () => fetchAPI<{nodes: GraphNode[], links: GraphLink[]}>('/graph/data').catch(() => ({
    nodes: [
      { id: 'n1', label: 'quantum entanglement', category: 'concept' },
      { id: 'n2', label: 'research.pdf', category: 'document' },
      { id: 'n3', label: 'physics', category: 'tag' },
    ],
    links: [
      { source: 'n2', target: 'n1', type: 'mentions' },
      { source: 'n2', target: 'n3', type: 'tagged' },
    ]
  })),
  
  // Chat
  chatSessions: () => fetchAPI<any[]>('/chat/sessions').catch(() => ([
    { id: 'c1', title: 'Quantum Physics Explainer', updatedAt: '2025-01-16T10:00:00Z' },
    { id: 'c2', title: 'Tax Prep 2024', updatedAt: '2025-01-15T14:30:00Z' },
  ]))
};
