import React from 'react';
import { glassCardClasses } from '../lib/utils';
import { Settings2, Database, Key, Webhook, SplitSquareHorizontal, Layers, Fingerprint } from 'lucide-react';

export default function ConfigView() {
  return (
    <div className="p-8 h-full overflow-y-auto max-w-[1600px] mx-auto">
      <header className="mb-8">
        <h2 className="text-2xl font-semibold text-slate-900 dark:text-slate-100">Configuration & Processes</h2>
        <p className="text-slate-600 dark:text-slate-400 text-sm mt-1">Configure advanced RAG strategies, data integrations, and parsing rules.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Chunking & Embedding Strategy */}
        <div className={`${glassCardClasses} p-6 flex flex-col`}>
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-purple-500/10 text-purple-600 dark:text-purple-400 rounded-lg"><SplitSquareHorizontal className="w-5 h-5"/></div>
            <div>
              <h3 className="text-lg font-medium text-slate-900 dark:text-slate-200">Chunking & Embedding Strategy</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">Tune how documents are split and embedded</p>
            </div>
          </div>
          
          <div className="space-y-5">
            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5 block">Semantic Chunk Size</label>
              <div className="flex items-center gap-3">
                <input type="range" min="256" max="2048" step="128" defaultValue="1024" className="flex-1 accent-purple-500" />
                <span className="text-sm text-slate-600 dark:text-slate-400 w-16 text-right font-mono bg-slate-50 dark:bg-slate-900 px-2 py-1 rounded border border-slate-200 dark:border-white/5">1024</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-1">Target token count per vector node</p>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5 block">Chunk Overlap</label>
              <div className="flex items-center gap-3">
                <input type="range" min="0" max="512" step="32" defaultValue="128" className="flex-1 accent-purple-500" />
                <span className="text-sm text-slate-600 dark:text-slate-400 w-16 text-right font-mono bg-slate-50 dark:bg-slate-900 px-2 py-1 rounded border border-slate-200 dark:border-white/5">128</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-1">Token overlap between adjacent chunks to preserve context</p>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5 block">Embedding Model</label>
              <select className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-white/10 rounded-lg text-sm text-slate-900 dark:text-slate-200 p-2.5 outline-none focus:border-purple-500/50">
                <option>text-embedding-3-small (Default)</option>
                <option>text-embedding-3-large</option>
                <option>nomic-embed-text-v1.5</option>
                <option>bge-m3 (Multilingual)</option>
              </select>
            </div>
          </div>
        </div>

        {/* External Data Connectors */}
        <div className={`${glassCardClasses} p-6 flex flex-col`}>
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-lg"><Webhook className="w-5 h-5"/></div>
            <div>
              <h3 className="text-lg font-medium text-slate-900 dark:text-slate-200">Data Connectors & Webhooks</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">Manage continuous ingestion sources</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="p-4 bg-slate-50/50 dark:bg-slate-900/50 rounded-xl border border-slate-200 dark:border-white/5 flex items-center justify-between group hover:border-emerald-500/30 transition-colors cursor-pointer">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center border border-slate-300 dark:border-white/10 text-slate-700 dark:text-slate-300">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-slate-900 dark:text-slate-200">Notion Workspace Sync</h4>
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1 mt-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> Synced 1 hour ago
                  </p>
                </div>
              </div>
              <button className="px-3 py-1.5 bg-slate-100 dark:bg-white/5 rounded-lg text-xs hover:bg-slate-200 dark:bg-white/10 transition-colors border border-slate-300 dark:border-white/10 text-slate-700 dark:text-slate-300">Manage</button>
            </div>

            <div className="p-4 bg-slate-50/50 dark:bg-slate-900/50 rounded-xl border border-slate-200 dark:border-white/5 flex items-center justify-between group hover:border-emerald-500/30 transition-colors cursor-pointer">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center border border-slate-300 dark:border-white/10 text-slate-700 dark:text-slate-300">
                  <Fingerprint className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-slate-900 dark:text-slate-200">Confluence Wiki</h4>
                  <p className="text-xs text-slate-500 mt-0.5">Not connected</p>
                </div>
              </div>
              <button className="px-3 py-1.5 bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 rounded-lg text-xs hover:bg-indigo-500/30 transition-colors border border-indigo-500/20">Connect</button>
            </div>

            <div className="p-4 bg-slate-50/50 dark:bg-slate-900/50 rounded-xl border border-slate-200 dark:border-white/5 flex items-center justify-between">
              <div>
                <h4 className="text-sm font-medium text-slate-900 dark:text-slate-200">Ingestion Webhook URL</h4>
                <p className="text-xs text-slate-500 mt-1 font-mono break-all text-emerald-600 dark:text-emerald-400/70">https://api.uroboros.local/v1/ingest?token=sk_xyz</p>
              </div>
              <button className="p-2 bg-slate-100 dark:bg-white/5 rounded-lg text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"><Key className="w-4 h-4"/></button>
            </div>
          </div>
        </div>

        {/* Auto-Tag Rules Engine (Updated) */}
        <div className={`${glassCardClasses} p-6 flex flex-col col-span-1 md:col-span-2`}>
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-lg"><Settings2 className="w-5 h-5"/></div>
            <div>
              <h3 className="text-lg font-medium text-slate-900 dark:text-slate-200">Metadata Extraction Rules</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">Automatically assign tags based on regex matching and LLM extraction across parsed file content.</p>
            </div>
          </div>
          
          <div className="flex-1 overflow-x-auto border border-slate-200 dark:border-white/5 rounded-xl bg-slate-50/30 dark:bg-slate-900/30">
            <table className="w-full text-left text-sm text-slate-700 dark:text-slate-300">
              <thead>
                <tr className="border-b border-slate-200 dark:border-white/5 bg-slate-50/50 dark:bg-slate-900/50">
                  <th className="px-4 py-3 font-medium text-slate-600 dark:text-slate-400">Target Tag</th>
                  <th className="px-4 py-3 font-medium text-slate-600 dark:text-slate-400">Match Strategy</th>
                  <th className="px-4 py-3 font-medium text-slate-600 dark:text-slate-400">Pattern / Prompt</th>
                  <th className="px-4 py-3 text-right font-medium text-slate-600 dark:text-slate-400">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                <tr className="hover:bg-white/[0.02]">
                  <td className="px-4 py-3"><span className="px-2 py-1 bg-indigo-500/20 text-indigo-300 rounded text-xs font-medium border border-indigo-500/20">invoice</span></td>
                  <td className="px-4 py-3 text-xs text-slate-600 dark:text-slate-400">Regex Match</td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-500 bg-white dark:bg-slate-950 p-2 rounded">/invoice(?:_|-| )?\d{"{4,}"}/i</td>
                  <td className="px-4 py-3 text-right">
                    <button className="text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:text-indigo-400 mr-3 text-xs font-medium transition-colors">Edit</button>
                  </td>
                </tr>
                <tr className="hover:bg-white/[0.02]">
                  <td className="px-4 py-3"><span className="px-2 py-1 bg-emerald-500/20 text-emerald-300 rounded text-xs font-medium border border-emerald-500/20">confidential</span></td>
                  <td className="px-4 py-3 text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1"><Layers className="w-3 h-3 text-emerald-600 dark:text-emerald-400"/> LLM Zero-Shot</td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-500 bg-white dark:bg-slate-950 p-2 rounded truncate max-w-xs">"Extract if document contains sensitive financial or personal data"</td>
                  <td className="px-4 py-3 text-right">
                    <button className="text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:text-indigo-400 mr-3 text-xs font-medium transition-colors">Edit</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <button className="mt-4 py-2.5 bg-indigo-500 text-white hover:bg-indigo-600 rounded-xl text-sm font-medium transition-colors w-full md:w-auto px-6 ml-auto">
            + Create New Rule
          </button>
        </div>
      </div>
    </div>
  );
}
